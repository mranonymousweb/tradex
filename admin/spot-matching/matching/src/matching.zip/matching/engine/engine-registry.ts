import { ModuleRef } from "@nestjs/core";
import { MarketEngine } from "./market-engine";
import { Injectable } from "@nestjs/common";

@Injectable()
export class EngineRegistry {

  private marketEngines = new Map<string, MarketEngine>();

  constructor(
    private readonly moduleRef: ModuleRef,
  ) {}

  getEngine(pair: string): MarketEngine | undefined {
    return this.marketEngines.get(pair);
  }

  async initMarket(pair: string): Promise<MarketEngine> {
    if (this.marketEngines.has(pair)) {
      return this.marketEngines.get(pair);
    }

    const engine = await this.moduleRef.create(MarketEngine);
    engine.configure(pair);
    await engine.init();

    this.marketEngines.set(pair, engine);

    return engine;
  }

  async shutdownMarket(pair: string) {
    const engine = this.marketEngines.get(pair);
    if (!engine) return;

    await engine.destroy();
    this.marketEngines.delete(pair);
  }
}
