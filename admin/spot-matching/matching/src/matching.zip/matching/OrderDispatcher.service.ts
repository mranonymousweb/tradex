import { Injectable, OnModuleInit } from "@nestjs/common";
import { Consumer, Kafka } from "kafkajs";
import { EngineRegistry } from "./engine/engine-registry";

@Injectable()
export class OrderDispatcherService implements OnModuleInit {
  private consumer: Consumer;

  constructor(
    private readonly kafka: Kafka,
    private readonly engineRegistry: EngineRegistry,
  ) {}

  async onModuleInit() {
    await this.initKafka();
  }

  private async initKafka() {
    this.consumer = this.kafka.consumer({
      groupId: 'matching-engine-group',
    });

    await this.consumer.connect();

    await this.consumer.subscribe({
      topic: 'orders',
    });

    await this.consumer.run({
      eachMessage: async ({ message }) => {
        if (!message.key || !message.value) return;

        const pair = message.key.toString();
        const payload = JSON.parse(message.value.toString());

        let engine = this.engineRegistry.getEngine(pair);

        if (!engine) {
            engine = await this.engineRegistry.initMarket(pair);
        }

        engine.enqueue(payload);
      },
    });
  }
}
