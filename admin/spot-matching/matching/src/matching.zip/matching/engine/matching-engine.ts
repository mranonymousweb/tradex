import { Injectable, OnModuleInit } from '@nestjs/common';
import { EngineRegistry } from './engine-registry';

@Injectable()
export class MatchingEngine implements OnModuleInit {
  constructor(private readonly registry: EngineRegistry) {}

  async onModuleInit() {
    // init همه بازارها
    await this.registry.initAllMarkets();
  }

  getMarketEngine(pair: string) {
    return this.registry.getEngine(pair);
  }
}
