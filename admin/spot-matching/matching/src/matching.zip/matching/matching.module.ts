import { Module } from '@nestjs/common';
import { CoreService } from 'src/core/core.service';
import { MatchingEngine } from './engine/matching-engine';
import { EngineRegistry } from './engine/engine-registry';
import { MatcherService } from './matcher/matcher.service';
import { MarketRecoveryService } from './recovery/market-recovery.service';

@Module({
  providers: [
    CoreService,
    MatcherService,
    MarketRecoveryService,
    EngineRegistry,
    MatchingEngine,
  ],
  exports: [MatchingEngine],
})
export class MatchingModule {}
