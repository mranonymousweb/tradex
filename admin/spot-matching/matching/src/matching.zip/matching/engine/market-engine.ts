import { IOrderPayload } from "src/common/interface/order-payload.interface";
import { CoreService } from "src/core/core.service";
import { Injectable } from "@nestjs/common";

@Injectable()
export class MarketEngine {
  private pair: string;

  private buyOrders: IOrderPayload[] = [];
  private sellOrders: IOrderPayload[] = [];
  private waitingOrders: IOrderPayload[] = [];

  private queue: IOrderPayload[] = [];
  private processing = false;

  constructor(
    private readonly coreService: CoreService,
  ) {}

  configure(pair: string) {
    this.pair = pair;
  }

  async init() {
  }

  async destroy() {
    this.buyOrders = [];
    this.sellOrders = [];
    this.waitingOrders = [];
    this.queue = [];
  }

  /* ✅ این متدی هست که ارورت رو حل می‌کنه */
  enqueue(order: IOrderPayload) {
    this.queue.push(order);
    this.process();
  }

  private async process() {
    if (this.processing) return;
    this.processing = true;

    while (this.queue.length > 0) {
      const order = this.queue.shift();
    }

    this.processing = false;
  }

 
}
