'use client';

import * as React from 'react';
import * as ScrollAreaPrimitive from '@radix-ui/react-scroll-area';
import { useLocale } from 'next-intl';
import { cn } from '@/lib/utils';
import { rtlLocales } from '@/utils/rtlLocales';

function ScrollArea({
    className,
    viewportClassName,
    children,
    viewportRef,
    ...props
}: React.ComponentPropsWithoutRef<typeof ScrollAreaPrimitive.Root> & {
    viewportRef?: React.Ref<HTMLDivElement>;
    viewportClassName?: string;
}) {
    const locale = useLocale();
    const dir = rtlLocales.includes(locale) ? 'rtl' : 'ltr';
    return (
        <ScrollAreaPrimitive.Root
            dir={dir}
            data-slot="scroll-area"
            className={cn('relative overflow-hidden', className)}
            {...props}
        >
            <ScrollAreaPrimitive.Viewport
                ref={viewportRef}
                className={cn('h-full w-full rounded-[inherit]', viewportClassName)}
            >
                {children}
            </ScrollAreaPrimitive.Viewport>
            <ScrollBar />
            <ScrollAreaPrimitive.Corner />
        </ScrollAreaPrimitive.Root>
    );
}

function ScrollBar({
    className,
    orientation = 'vertical',
    ...props
}: React.ComponentPropsWithoutRef<
    typeof ScrollAreaPrimitive.ScrollAreaScrollbar
>) {
    return (
        <ScrollAreaPrimitive.ScrollAreaScrollbar
            data-slot="scroll-area-scrollbar"
            orientation={orientation}
            className={cn(
                'flex touch-none select-none transition-colors',
                orientation === 'vertical' &&
                'h-full w-2 border-l border-l-transparent p-[1px]',
                orientation === 'horizontal' &&
                'h-2 flex-col border-t border-t-transparent p-[1px]',
                className,
            )}
            {...props}
        >
            <ScrollAreaPrimitive.ScrollAreaThumb className="relative flex-1 rounded-full bg-border" />
        </ScrollAreaPrimitive.ScrollAreaScrollbar>
    );
}

export { ScrollArea, ScrollBar };
